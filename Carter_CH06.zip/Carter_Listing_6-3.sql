USE WideWorldImporters
GO

SELECT TOP 3
	  VehicleRegistration
	, ChillerSensorNumber
	, Temperature
FROM Warehouse.VehicleTemperatures 
ORDER BY Temperature DESC ;
