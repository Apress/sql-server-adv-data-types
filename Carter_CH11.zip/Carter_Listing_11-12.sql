DECLARE @StateBorder GEOGRAPHY = (
		SELECT Border 
		FROM Application.StateProvinces 
		WHERE StateProvinceName = 'Alabama') ;

SELECT 
	  GEOGRAPHY::EnvelopeAggregate(DeliveryLocation).STArea() AS AreaInSquareMetres
	, GEOGRAPHY::EnvelopeAggregate(DeliveryLocation) AS EnvelopeObject
FROM Sales.Customers
WHERE DeliveryLocation.STWithin(@StateBorder) = 1 ;
