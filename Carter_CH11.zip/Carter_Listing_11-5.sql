DECLARE @Polygon GEOMETRY ;

SET @Polygon = 'POLYGON((0 0, 10 0, 10 10, 0 10, 0 0))' ;

SELECT @Polygon ;
