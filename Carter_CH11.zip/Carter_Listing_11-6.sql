--SET Variable As NULL by passing A NULL Directly

DECLARE @Polygon GEOMETRY ;

SET @Polygon = NULL ;

SELECT @Polygon ;

--Set A Variable As NULL by using the read-only Null Property

SET @Polygon = GEOMETRY::[Null] ;

SELECT @Polygon ;
