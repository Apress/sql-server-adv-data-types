DECLARE @StateBorder GEOGRAPHY = (
		SELECT Border 
		FROM Application.StateProvinces 
		WHERE StateProvinceName = 'Alabama') ;

DECLARE @Office GEOGRAPHY = (
		SELECT DeliveryLocation 
		FROM Application.SystemParameters) ;

DECLARE @MilesRatio INT = 0.000621371 ;


SELECT  
	   Customer.CustomerName AS CustomerName
	 , City.CityName AS City
	 , Customer.DeliveryLocation.ToString() AS DeliveryLocation
	 , Customer.DeliveryLocation.STDistance(@Office) * @MilesRatio AS DeliveryDistanceMiles
	 , Customer.DeliveryLocation.STSrid AS SRID
	 , srid.unit_of_measure
FROM SALES.Customers Customer
INNER JOIN Application.Cities City
	ON City.CityID = Customer.DeliveryCityID
INNER JOIN sys.spatial_reference_systems srid
	ON srid.spatial_reference_id = Customer.DeliveryLocation.STSrid
WHERE Customer.DeliveryLocation.STWithin(@StateBorder) = 1
ORDER BY DeliveryDistanceMiles ;
