DECLARE @LineString GEOMETRY ;  

SET @LineString = 
GEOMETRY::GeomFromGml('<LineString xmlns="http://www.opengis.net/gml"> 
<posList>0 0 4.5 5 4.5 0 0 0</posList> </LineString>', 0) ;
  
SELECT @LineString ;
