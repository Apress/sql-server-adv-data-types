DECLARE @Point GEOMETRY ;   

SET @Point = GEOMETRY::Point(10, 10, 0) ;  

SELECT @Point ;
