DECLARE @LineString GEOMETRY ;  

SET @LineString = GEOMETRY::STGeomFromText('POLYGON((0 0, 10 10, 10 0, 0 10))', 0) ;  

SELECT 
	  @LineString.STIsValid() AS IsValid
	, @LineString.MakeValid().ToString() AS Fixed
	, @LineString AS WKB ;
