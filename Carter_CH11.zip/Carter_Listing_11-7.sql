DECLARE @Polygon GEOMETRY ;  

SET @Polygon = GEOMETRY::STGeomFromText('POLYGON((0 0, 10 10, 10 0, 0 10, 0 0))', 0) ;  

SELECT 
	  @Polygon.STIsValid() AS IsValid
	, @Polygon.MakeValid().ToString() AS Fixed
	, @Polygon AS WKB ; 
