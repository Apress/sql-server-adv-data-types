DECLARE @LineString GEOMETRY ;

SET @LineString = GEOMETRY::STLineFromText('LINESTRING(0 0, 4.5 5, 4.5 0, 0 0)', 0)

SELECT @LineString ;
