DECLARE @StateBorder GEOGRAPHY = (
		SELECT Border 
		FROM Application.StateProvinces 
		WHERE StateProvinceName = 'Alabama') ;

SELECT  
	   Customer.CustomerName AS CustomerName
	 , City.CityName AS City
	 , Customer.DeliveryLocation.ToString() AS DeliveryLocation
FROM SALES.Customers Customer
INNER JOIN Application.Cities City
	ON City.CityID = Customer.DeliveryCityID
WHERE Customer.DeliveryLocation.STWithin(@StateBorder) = 1 ;
