USE WideWorldImporters
GO

SELECT
	OrderID
	, CustomerID
	, SalespersonPersonID
	, OrderDate
	, Comments
FROM Sales.Orders
WHERE CustomerID = 1060 
FOR JSON AUTO, ROOT('SalesOrders') ;
