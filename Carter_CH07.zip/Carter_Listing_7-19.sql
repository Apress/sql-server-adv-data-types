USE WideWorldImporters
GO

SELECT
	  Orders.OrderID
	, Orders.CustomerID
	, Orders.SalespersonPersonID
	, Orders.OrderDate
	, Orders.Comments
	, OrderLines.StockItemID
	, OrderLines.UnitPrice
	, OrderLines.Quantity
	, Products.StockItemName
FROM Sales.Orders Orders
INNER JOIN Sales.OrderLines OrderLines
	ON OrderLines.OrderID = Orders.OrderID
INNER JOIN Warehouse.StockItems Products
	ON Products.StockItemID = OrderLines.StockItemID
WHERE CustomerID = 1060 
	AND Orders.OrderID = 72646
FOR JSON AUTO, ROOT('SalesOrders'), INCLUDE_NULL_VALUES ;
