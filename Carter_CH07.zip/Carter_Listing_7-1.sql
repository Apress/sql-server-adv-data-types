USE WideWorldImporters
GO

SELECT
	OrderID
	, CustomerID
	, SalespersonPersonID
	, OrderDate
FROM Sales.Orders
WHERE CustomerID = 1060 ;
