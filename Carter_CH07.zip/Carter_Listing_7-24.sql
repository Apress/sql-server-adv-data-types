USE WideWorldImporters
GO

SELECT
	  Orders.OrderID AS 'OrderDetails.OrderID'
	, Customers.FullName AS 'OrderDetails.Customer'
	, SalesPeople.FullName AS 'OrderDetails.SalesPerson'
	, Orders.OrderDate AS 'OrderDetails.OrderDate'
	, Orders.Comments AS 'OrderDetails.Comments'
	, OrderLines.UnitPrice AS 'OrderDetails.LineItems.UnitPrice'
	, OrderLines.Quantity AS 'OrderDetails.LineItems.Quantity'
	, Products.StockItemName AS 'OrderDetails.LineItems.ProductName'
FROM Sales.Orders Orders
INNER JOIN Sales.OrderLines OrderLines
	ON OrderLines.OrderID = Orders.OrderID
INNER JOIN Warehouse.StockItems Products
	ON Products.StockItemID = OrderLines.StockItemID
INNER JOIN Application.People Customers
	ON Customers.PersonID = Orders.CustomerID
INNER JOIN Application.People SalesPeople
	ON SalesPeople.PersonID = Orders.SalespersonPersonID
WHERE CustomerID = 1060 
	AND orders.OrderID = 72646
FOR JSON PATH, ROOT('SalesOrders'), INCLUDE_NULL_VALUES ;
