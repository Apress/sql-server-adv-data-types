USE WideWorldImporters
GO

SELECT
	OrderID
	, CustomerID
	, SalespersonPersonID
	, OrderDate
FROM Sales.Orders
WHERE CustomerID = 1060 
FOR JSON AUTO, WITHOUT_ARRAY_WRAPPER ;
