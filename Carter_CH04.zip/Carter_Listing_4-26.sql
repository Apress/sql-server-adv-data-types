DECLARE @SalesOrder xml;         
SET @SalesOrder = '
<Order>
  <OrderHeader>
    <CustomerName>Camille Authier</CustomerName>
    <OrderDate>2013-01-02</OrderDate>
    <OrderID>121</OrderID>
  </OrderHeader>
  <OrderDetails>
    <Product ProductID="2" ProductName="USB rocket launcher (Gray)" Price="25" Qty="9" />
    <Product ProductID="22" ProductName="DBA joke mug - it depends (White)" Price="13" Qty="6" />
  </OrderDetails>
</Order>'  ;    

DECLARE @ProductName NVARCHAR(200) ;

SET @ProductName = 'DBA joke mug - it depends (White)' ;

DECLARE @Quantity INT ;

SET @Quantity = 10
 
      
SET @SalesOrder.modify('         
replace value of (/Order/OrderDetails/Product[@ProductName = sql:variable("@ProductName")]/@Qty)[1]                             
with "10"
') ;

SELECT @SalesOrder ;    
