SELECT @XML.query('
    for $product in /SalesOrders/Order/OrderDetails/Product/@ProductName
	 let $customer := /SalesOrders/Order/OrderHeader/CustomerName
	 where $product = "Dinosaur battery-powered slippers (Green) M"
	   or $product = "Dinosaur battery-powered slippers (Green) XL"
	 order by $product
	return 
	<Customer>
	  {$customer[1]}
	<OrderDetails>
	  {$product}
	</OrderDetails>
	</Customer>
') ;
