USE WideWorldImporters
GO

CREATE XML SCHEMA COLLECTION OrderSummary AS  
N'<?xml version="1.0" encoding="utf-16"?>
<xs:schema attributeFormDefault="unqualified" elementFormDefault="qualified" xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:element name="SalesOrders">
    <xs:complexType>
      <xs:sequence>
        <xs:element maxOccurs="unbounded" name="Order">
          <xs:complexType>
            <xs:sequence>
              <xs:element name="OrderHeader">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name="CustomerName" type="xs:string" />
                    <xs:element name="OrderDate" type="xs:date" />
                    <xs:element name="OrderID" type="xs:unsignedInt" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name="OrderDetails">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element maxOccurs="unbounded" name="Product">
                      <xs:complexType>
                        <xs:attribute name="ProductID" type="xs:unsignedByte" use="required" />
                        <xs:attribute name="ProductName" type="xs:string" use="required" />
                        <xs:attribute name="Price" type="xs:decimal" use="required" />
                        <xs:attribute name="Qty" type="xs:unsignedShort" use="required" />
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>' ;  
