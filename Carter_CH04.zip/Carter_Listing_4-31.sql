USE WideWorldImporters
GO

SELECT
      CustomerID
	, TempCol.value('@Qty', 'INT') AS Quantity
	, TempCol.value('@ProductName', 'NVARCHAR(70)') AS ProductName
	, TempCol.query('.') AS Product
FROM Sales.CustomerOrderSummary
CROSS APPLY OrderSummary.nodes('SalesOrders/Order/OrderDetails/Product') TempTable(TempCol) 
WHERE CustomerID = 841 
ORDER BY TempCol.value('@Qty', 'INT') DESC ;
