SELECT @XML.query('
	for $product in /SalesOrders/Order[2]/OrderDetails/Product/@ProductName
	return string($product)
') ;
