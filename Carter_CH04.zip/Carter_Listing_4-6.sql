USE WideWorldImporters
GO

SELECT 
        CustomerID
      , OrderSummary
FROM WideWorldImporters.Sales.CustomerOrderSummary
WHERE OrderSummary.value('(/SalesOrders/Order/OrderHeader/CustomerName)[1]', 'nvarchar(100)') = 'Tailspin Toys (Absecon, NJ)' ;
