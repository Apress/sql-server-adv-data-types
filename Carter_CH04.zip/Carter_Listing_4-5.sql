USE WideWorldImporters
GO

SELECT
      CustomerID
    , OrderSummary
    , OrderSummary.value('(/SalesOrders/Order/OrderHeader/CustomerName)[1]', 'nvarchar(100)') AS CustomerName
FROM Sales.CustomerOrderSummary ;
