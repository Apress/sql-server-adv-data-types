SELECT 
        CustomerID
      , OrderSummary
FROM WideWorldImporters.Sales.CustomerOrderSummary
WHERE OrderSummary.exist('SalesOrders/Order/OrderHeader/CustomerName[(text()[1]) eq "Tailspin Toys (Absecon, NJ)"]') = 1 ;
