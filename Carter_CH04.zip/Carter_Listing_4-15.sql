SELECT @XML.query('
    for $product in /SalesOrders/Order/OrderDetails/Product/@ProductName
	 let $customer := /SalesOrders/Order/OrderHeader/CustomerName
	return 
	<Customer>
	  {$customer[1]}
	<OrderDetails>
	  {$product}
	</OrderDetails>
	</Customer>
') ; 
