SELECT @XML.query('
	 let $product := /SalesOrders/Order[1]/OrderDetails/Product/@ProductName
	return string($product[1])
') ;
