USE WideWorldImporters
GO

DECLARE @Gold NVARCHAR(3)

DECLARE @CustomerName NVARCHAR(100)

SET @Gold = 'Yes'

SET @CustomerName = 'Tailspin Toys (Absecon, NJ)'

SELECT
      OrderSummary
	, OrderSummary.value('(/SalesOrders/Order/OrderHeader/CustomerName)[1]', 'nvarchar(100)') AS CustomerName
	, OrderSummary.value('(/SalesOrders/Order/OrderHeader/OrderID)[1]', 'int') AS OrderID
	, OrderSummary.query('/SalesOrders/Order/OrderDetails/Product') AS ProductsOrdered
	, OrderSummary.query('<CustomerDetails> CustomerID = "{ sql:column("CustomerID") }" GoldCustomer = "{ sql:variable("@Gold") }"  </CustomerDetails>') As CustomerDetails
FROM Sales.CustomerOrderSummary 
WHERE OrderSummary.exist('SalesOrders/Order/OrderHeader/CustomerName[(text()[1]) eq sql:variable("@CustomerName") ]') = 1 ;
