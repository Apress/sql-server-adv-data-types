ALTER TABLE Sales.CustomerOrderSummary
	ALTER COLUMN OrderSummary XML(OrderSummary) ;
