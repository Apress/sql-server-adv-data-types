DECLARE @SalesOrders XML

SET @SalesOrders = 
'<SalesOrder OrderDate="2016-05-27" OrderID="73356">
	  <Customers CustomerName="Agrita Abele">
		<Product StockItemName="Chocolate sharks 250g">
		  <LineItem Quantity="192" UnitPrice="8.55" />
		</Product>
	  </Customers>
	</SalesOrder>' ;

SELECT @SalesOrders.exist('SalesOrder/Customers/Product[(@StockItemName) eq "Chocolate sharks 250g"]') ;
