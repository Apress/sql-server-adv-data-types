DECLARE @XML XML = N�<SalesOrders>
  <Order>
    <OrderHeader>
      <CustomerName>Tailspin Toys (Absecon, NJ)</CustomerName>
      <OrderDate>2013-01-17</OrderDate>
      <OrderID>950</OrderID>
    </OrderHeader>
    <OrderDetails>
      <Product ProductID="119" ProductName="Dinosaur battery-powered slippers (Green) M" Price="32.00" Qty="2" />
      <Product ProductID="61" ProductName="RC toy sedan car with remote control (Green) 1/50 scale" Price="25.00" Qty="2" />
      <Product ProductID="194" ProductName="Black and orange glass with care despatch tape  48mmx100m" Price="4.10" Qty="216" />
      <Product ProductID="104" ProductName="Alien officer hoodie (Black) 3XL" Price="35.00" Qty="2" />
    </OrderDetails>
  </Order>
  <Order>
    <OrderHeader>
      <CustomerName>Tailspin Toys (Absecon, NJ)</CustomerName>
      <OrderDate>2013-01-29</OrderDate>
      <OrderID>1452</OrderID>
    </OrderHeader>
    <OrderDetails>
      <Product ProductID="33" ProductName="Developer joke mug - that's a hardware problem (Black)" Price="13.00" Qty="9" />
      <Product ProductID="121" ProductName="Dinosaur battery-powered slippers (Green) XL" Price="32.00" Qty="1" />
    </OrderDetails>
  </Order>
<SalesOrders>�
