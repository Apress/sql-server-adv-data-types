DECLARE @SalesOrder XML ;

SET @SalesOrder = '
<SalesOrders>
  <Order>
    <OrderDate>2013-01-02</OrderDate>
    <OrderHeader>
      <CustomerName>Camille Authier</CustomerName>
	</OrderHeader>
    <OrderDetails>
      <Product ProductID="45" ProductName="Developer joke mug - there are 10 types of people in the world (Black)" Price="13" Qty="7" />
      <Product ProductID="58" ProductName="RC toy sedan car with remote control (Black) 1/50 scale" Price="25" Qty="4" />
    </OrderDetails>
  </Order>
  <Order>
    <OrderDate>2013-01-02</OrderDate>
    <OrderHeader>
      <CustomerName>Camille Authier</CustomerName>
	</OrderHeader>
    <OrderDetails OrderID = "122">
      <Product ProductID="22" ProductName="DBA joke mug - it depends (White)" Price="13" Qty="6" />
      <Product ProductID="2" ProductName="USB rocket launcher (Gray)" Price="25" Qty="9" />
      <Product ProductID="111" ProductName="Superhero action jacket (Blue) M" Price="30" Qty="10" />
      <Product ProductID="116" ProductName="Superhero action jacket (Blue) 4XL" Price="34" Qty="4" />
    </OrderDetails>
  </Order>
</SalesOrders>' ;


SELECT 
	  TempCol.value('@ProductID', 'INT') AS ProductID
	, TempCol.value('@ProductName', 'NVARCHAR(70)') AS ProductName
	, TempCol.value('@Qty', 'INT') AS Quantity
	, TempCol.value('../@OrderID', 'INT') AS OrderID
	, TempCol.value('../../OrderDate[1]', 'NVARCHAR(10)') AS OorderDate
	, TempCol.value('../../OrderHeader[1]/CustomerName[1]', 'NVARCHAR(15)') AS CustomerName
FROM @SalesOrder.nodes('SalesOrders/Order/OrderDetails/Product') TempTable(TempCol) ;
