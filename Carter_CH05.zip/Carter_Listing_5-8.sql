DROP INDEX [PrimaryXmlIndex-OrderSummary-OrderSummary] ON Sales.OrderSummary ;
GO

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE
GO

SET STATISTICS TIME ON
GO

SELECT *  
FROM Sales.OrderSummary 
WHERE OrderSummary.exist('/SalesOrders/Order/OrderDetails/Product/.[@ProductID = 223]') = 1 ;
