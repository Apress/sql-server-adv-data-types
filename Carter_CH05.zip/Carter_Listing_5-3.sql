USE WideWorldImporters
GO

ALTER TABLE Sales.OrderSummary ADD CONSTRAINT
	PK_OrderSummary PRIMARY KEY CLUSTERED (ID) ;
