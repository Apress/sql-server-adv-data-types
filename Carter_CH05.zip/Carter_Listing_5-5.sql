USE WideWorldImporters
GO

CREATE XML INDEX [SecondaryXmlIndex-OrderSummary-Path]
	ON Sales.OrderSummary (OrderSummary)
USING XML INDEX [PrimaryXmlIndex-OrderSummary-OrderSummary] FOR PATH ;
GO
