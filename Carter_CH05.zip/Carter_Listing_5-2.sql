USE WideWorldImporters
GO

CREATE CLUSTERED INDEX [ClusteredIndex-OrderSummary-ID] ON Sales.OrderSummary (ID) ;
GO
