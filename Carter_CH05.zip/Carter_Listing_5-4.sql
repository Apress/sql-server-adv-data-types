USE WideWorldImporters
GO


CREATE PRIMARY XML INDEX [PrimaryXmlIndex-OrderSummary-OrderSummary] 
	ON Sales.OrderSummary ([OrderSummary]) ;
GO
