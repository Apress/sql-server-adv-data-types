USE WideWorldImporters
GO

SELECT 
      SalesAreaName
    , SalesAreaLevel
    , sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalLocation
FROM Sales.SalesAreaHierarchyID ;
