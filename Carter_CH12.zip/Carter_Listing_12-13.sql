USE WideWorldImporters
GO

SELECT NewNode.ToString() 
FROM
(
SELECT 
	SalesAreaHierarchy.GetDescendant(0x6AC0,0x6B40) AS NewNode
FROM Sales.SalesAreaHierarchyID
WHERE SalesAreaName = 'America'
) NewNode ;
