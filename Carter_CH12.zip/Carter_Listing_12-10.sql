--Returns Hexidecimal Representation Of Node

SELECT HierarchyID::Parse('/1/1/2/2/') ;

--Throws An Error Because Trailing / Is Missing

SELECT HierarchyID::Parse('/1/1/2/2') ;
