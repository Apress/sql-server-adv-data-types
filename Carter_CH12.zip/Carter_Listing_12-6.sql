USE WideWorldImporters
GO

CREATE TABLE Sales.SalesAreaHierarchyID
(
SalesAreaID               INT                       NOT NULL    PRIMARY KEY,
SalesAreaHierarchy   HIERARCHYID     NOT NULL,
SalesAreaName           NVARCHAR(20)    NOT NULL,
CountOfSalesPeople    INT                        NULL,
SalesYTD                     MONEY                 NULL
) ;

INSERT INTO Sales.SalesAreaHierarchyID (
	  SalesAreaID
	, SalesAreaHierarchy
	, SalesAreaName
	, CountOfSalesPeople
	, SalesYTD
)
VALUES 
(1, '/', 'GlobalSales', NULL, NULL),
(2, '/1/', 'Europe', NULL, NULL),
(3, '/2/', 'America', NULL, NULL),
(4, '/1/1/', 'UK', 3, 300000),
(5, '/1/2/', 'Western Eurpoe', NULL, NULL),
(6, '/1/3/', 'Eastern Europe', NULL, NULL),
(7, '/2/1/', 'Canada', 4, 350000),
(8, '/2/2/', 'USA', NULL, NULL),
(9, '/2/3/', 'LTAM', NULL, NULL),
(10, '/1/2/1/', 'Germany', 3, 150000),
(11, '/1/2/2/', 'France', 2, 100000),
(12, '/1/3/1/', 'Hungary', 1, 50000),
(13, '/1/3/2/', 'Slovakia', 2, 80000),
(14, '/2/2/1/', 'Eastern', 4, 140000),
(15, '/2/2/2/', 'Western', 3, 280000),
(16, '/2/3/1/', 'Brazil', 1, 100000),
(17, '/2/3/2/', 'Agentina', 2, 70000),
(18, '/2/2/1/1/', 'New York', 2, 120000) ;
