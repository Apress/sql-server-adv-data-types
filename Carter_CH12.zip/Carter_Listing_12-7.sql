USE WideWorldImporters
GO

SELECT 
	  SUM(DATALENGTH(salesareahierarchy)) AS SizeOfHierarchyID
	, SUM(DATALENGTH(parentsalesareaid)) AS SizeOfTraditional
FROM Sales.SalesAreaHierarchyID SalesAreaHierarchy
INNER JOIN sales.SalesAreaTraditionalHierarchy SalesAreaTraditional
	ON SalesAreaHierarchy.SalesAreaID = SalesAreaTraditional.SalesAreaID ;
