WITH AreaHierarchy (SalesAreaID, SalesYTD, ParentSalesAreaID) 
AS
(
	SELECT 
		  SalesAreaID
		, SalesYTD
		, ParentSalesAreaID
      FROM Sales.SalesAreaTraditionalHierarchy RootLevel
      WHERE SalesAreaName = 'America'
      UNION ALL 
      SELECT
          Area.SalesAreaID
	, Area.SalesYTD
	, Area.ParentSalesAreaID
      FROM Sales.SalesAreaTraditionalHierarchy Area
      INNER JOIN AreaHierarchy 
	ON Area.ParentSalesAreaID = AreaHierarchy.SalesAreaID
)

SELECT SUM(SalesYTD) 
FROM AreaHierarchy ;
