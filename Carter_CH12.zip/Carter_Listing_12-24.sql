USE WideWorldImporters
GO

SELECT 
      SalesAreaName
    , sys.fn_PhysLocFormatter(%%physloc%%) AS PhysicalLocation
FROM Sales.SalesAreaHierarchyID ;
