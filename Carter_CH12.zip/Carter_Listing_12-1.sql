USE WideWorldImporters
GO

CREATE TABLE Sales.SalesAreaTraditionalHierarchy
(
	SalesAreaID		INT	NOT NULL	PRIMARY KEY,
	ParentSalesAreaID	INT	NULL	
                                       REFERENCES Sales.SalesAreaTraditionalHierarchy(SalesAreaID),
	SalesAreaName		NVARCHAR(20)	NOT NULL,
	CountOfSalesPeople	INT	NULL,
	SalesYTD		MONEY	NULL
) ;

INSERT INTO Sales.SalesAreaTraditionalHierarchy (
	  SalesAreaID
	, ParentSalesAreaID
	, SalesAreaName
	, CountOfSalesPeople
	, SalesYTD
)
VALUES 
(1, NULL, 'GlobalSales', NULL, NULL),
(2, 1, 'Europe', NULL, NULL),
(3, 1, 'America', NULL, NULL),
(4, 2, 'UK', 3, 300000),
(5, 2, 'Western Eurpoe', NULL, NULL),
(6, 2, 'Eastern Europe', NULL, NULL),
(7, 3, 'Canada', 4, 350000),
(8, 3, 'USA', NULL, NULL),
(9, 3, 'LTAM', NULL, NULL),
(10, 5, 'Germany', 3, 150000),
(11, 5, 'France', 2, 100000),
(12, 6, 'Hungary', 1, 50000),
(13, 6, 'Slovakia', 2, 80000),
(14, 8, 'Eastern', 4, 140000),
(15, 8, 'Western', 3, 280000),
(16, 9, 'Brazil', 1, 100000),
(17, 9, 'Agentina', 2, 70000),
(18, 14, 'New York', 2, 120000) ;
