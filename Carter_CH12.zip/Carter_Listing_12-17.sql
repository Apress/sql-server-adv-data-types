USE WideWorldImporters
GO

SELECT 
                CurrentNode.SalesAreaName AS SalesArea
	, ParentNode.SalesAreaName AS ParentSalesArea
	, GrandParentNode.SalesAreaName AS GrandParentSalesArea
FROM Sales.SalesAreaHierarchyID Base
INNER JOIN Sales.SalesAreaHierarchyID CurrentNode
	ON CurrentNode.SalesAreaHierarchy = Base.SalesAreaHierarchy.GetAncestor(0)
INNER JOIN Sales.SalesAreaHierarchyID ParentNode
	ON ParentNode.SalesAreaHierarchy = Base.SalesAreaHierarchy.GetAncestor(1)
INNER JOIN Sales.SalesAreaHierarchyID GrandParentNode
	ON GrandParentNode.SalesAreaHierarchy = Base.SalesAreaHierarchy.GetAncestor(2)
WHERE Base.SalesAreaName = 'Spain' ;
