USE WideWorldImporters
GO

SELECT
	SalesAreaName
FROM Sales.SalesAreaHierarchyID
WHERE SalesAreaHierarchy.GetLevel() =
	(
	SELECT 
		MAX(SalesAreaHierarchy.GetLevel())
	FROM Sales.SalesAreaHierarchyID
	) ;
