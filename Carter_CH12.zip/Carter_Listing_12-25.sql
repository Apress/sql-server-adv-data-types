USE WideWorldImporters
GO

ALTER TABLE Sales.SalesAreaHierarchyID ADD
	SalesAreaLevel INT NULL ;
GO

UPDATE Sales.SalesAreaHierarchyID
SET SalesAreaLevel = SalesAreaHierarchy.GetLevel() ;
