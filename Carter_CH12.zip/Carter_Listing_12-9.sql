USE WideWorldImporters
GO

SELECT
	  SalesAreaName
	, SalesAreaHierarchy
	, SalesAreaHierarchy.ToString() AS SalesAreaHierarchyString
FROM Sales.SalesAreaHierarchyID ;
