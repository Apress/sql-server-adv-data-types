USE WideWorldImporters
GO

DROP INDEX SalesAreaHierarchyDepthFirst ON Sales.SalesAreaHierarchyID ;
GO

CREATE CLUSTERED INDEX SalesAreaHierarchyBredthFirst
	ON Sales.SalesAreaHierarchyID(SalesAreaLevel, SalesAreaHierarchy) ;
