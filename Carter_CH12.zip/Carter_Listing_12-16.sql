USE WideWorldImporters
GO

DECLARE @America HIERARCHYID = 
(
    SELECT SalesAreaHierarchy 
    FROM Sales.SalesAreaHierarchyID 
    WHERE SalesAreaName = 'America'
) ;

DECLARE @WesternEurope HIERARCHYID = 
(
    SELECT SalesAreaHierarchy 
	FROM Sales.SalesAreaHierarchyID 
	WHERE SalesAreaName = 'Western Eurpoe'
) ; 

UPDATE Sales.SalesAreaHierarchyID
SET SalesAreaHierarchy = 
(
SELECT SalesAreaHierarchy.GetReparentedValue(@America,@WesternEurope)
FROM Sales.SalesAreaHierarchyID
WHERE SalesAreaHierarchy = 0x6B16
) 
WHERE SalesAreaHierarchy = 0x6B16 ;
