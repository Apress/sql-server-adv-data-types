USE WideWorldImporters
GO

SELECT 
	   SalesAreaName
	,  SalesAreaHierarchy.ToString()
FROM Sales.SalesAreaHierarchyID
WHERE SalesAreaHierarchy = HierarchyID::GetRoot() ;
