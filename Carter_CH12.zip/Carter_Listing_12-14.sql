USE WideWorldImporters
GO

INSERT INTO Sales.SalesAreaHierarchyID 
        (
		  SalesAreaID
		, SalesAreaHierarchy
		, SalesAreaName
		, CountOfSalesPeople
		, SalesYTD
		)
SELECT 
	(SELECT MAX(SalesAreaID) + 1 FROM Sales.SalesAreaHierarchyID)
              ,  SalesAreaHierarchy.GetDescendant(0x6AC0,0x6B40)
	, 'Spain'
	, 2
	, 200000
FROM Sales.SalesAreaHierarchyID
WHERE SalesAreaName = 'America' ;
