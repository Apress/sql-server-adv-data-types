USE WideWorldImporters
GO

SELECT
	  SalesAreaName
	, SalesAreaHierarchy
FROM Sales.SalesAreaHierarchyID ;
