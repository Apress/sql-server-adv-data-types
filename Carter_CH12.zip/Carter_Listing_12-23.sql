USE WideWorldImporters
GO

ALTER TABLE Sales.SalesAreaHierarchyID
	DROP CONSTRAINT PK__SalesAre__DB0A1ED5D7B258FB ;
GO

CREATE CLUSTERED INDEX SalesAreaHierarchyDepthFirst
	ON Sales.SalesAreaHierarchyID(SalesAreaHierarchy) ;
GO
