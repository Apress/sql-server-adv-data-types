USE WideWorldImporters
GO

DECLARE @America HIERARCHYID = 
(
    SELECT SalesAreaHierarchy 
    FROM Sales.SalesAreaHierarchyID 
    WHERE SalesAreaName = 'America'
) ;

DECLARE @WesternEurope HIERARCHYID = 
(
    SELECT SalesAreaHierarchy 
    FROM Sales.SalesAreaHierarchyID 
    WHERE SalesAreaName = 'Western Eurpoe'
) ; 

SELECT Area.ToString() 
FROM 
(
SELECT SalesAreaHierarchy.GetReparentedValue(@America,@WesternEurope) AS Area
FROM Sales.SalesAreaHierarchyID
WHERE SalesAreaHierarchy = 0x6B16
) NewNodePath ;
