SELECT 
	  Customers.CustomerName
	, SalesOrder.OrderDate 
	, SalesOrder.OrderID
	, LineItem.Quantity
	, LineItem.UnitPrice
	, Product.StockItemName
FROM Sales.Orders SalesOrder
INNER JOIN Sales.OrderLines LineItem
	ON LineItem.OrderID = SalesOrder.OrderID
INNER JOIN Warehouse.StockItems Product
	ON Product.StockItemID = LineItem.StockItemID
INNER JOIN Sales.Customers Customers
	ON Customers.CustomerID = SalesOrder.CustomerID
WHERE customers.CustomerName = 'Agrita Abele'
FOR XML AUTO ;
