SELECT 
	  SalesOrder.OrderDate
	, Customers.CustomerName
	, SalesOrder.OrderID
	, Product.StockItemName
	, LineItem.Quantity
	, LineItem.UnitPrice
FROM Sales.Orders SalesOrder
INNER JOIN Sales.OrderLines LineItem
	ON LineItem.OrderID = SalesOrder.OrderID
INNER JOIN Warehouse.StockItems Product
	ON Product.StockItemID = LineItem.StockItemID
INNER JOIN Sales.Customers Customers
	ON Customers.CustomerID = SalesOrder.CustomerID
WHERE customers.CustomerName = 'Agrita Abele'
FOR XML AUTO ;
