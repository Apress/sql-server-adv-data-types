SELECT  
		  1 AS Tag
		, 0 AS Parent
		, SalesOrder.OrderID AS [OrderDetails!1!SalesOrderID]
		, SalesOrder.OrderDate AS [OrderDetails!1!OrderDate]
		, SalesOrder.CustomerID AS [OrderDetails!1!CustomerID]
		, NULL AS [SalesPerson!2!SalesPersonName]
		, NULL AS [LineItem!3!LineTotal!ELEMENT]
		, NULL AS [LineItem!3!ProductName!ELEMENT]
		, NULL AS [LineItem!3!OrderQty!ELEMENT]  
FROM   Sales.Orders  SalesOrder
INNER JOIN Sales.Customers Customers
	ON Customers.CustomerID = SalesOrder.CustomerID
WHERE customers.CustomerName = 'Agrita Abele'
UNION ALL   
SELECT 
		  2 AS Tag
		, 1 AS Parent
		, SalesOrder.OrderID
		, NULL
		, NULL
		, People.FullName
		, NULL
		, NULL
		, NULL           
FROM   Sales.Orders SalesOrder
INNER JOIN Sales.Customers Customers
	ON Customers.CustomerID = SalesOrder.CustomerID
INNER JOIN Application.People People
	ON People.PersonID = SalesOrder.SalespersonPersonID
WHERE customers.CustomerName = 'Agrita Abele'
UNION ALL  
SELECT 
		  3 AS Tag
		, 1 AS Parent
		, SalesOrder.OrderID
		, NULL
		, NULL
		, People.FullName
		, LineItem.UnitPrice
		, Product.StockItemName
		, LineItem.Quantity     
FROM    Sales.Orders SalesOrder
INNER JOIN Sales.OrderLines LineItem
              ON   SalesOrder.OrderID = LineItem.OrderID  
INNER JOIN Sales.Customers Customers
	ON Customers.CustomerID = SalesOrder.CustomerID
INNER JOIN Warehouse.StockItems Product
	ON Product.StockItemID = LineItem.StockItemID
INNER JOIN Application.People People
	ON People.PersonID = SalesOrder.SalespersonPersonID
WHERE customers.CustomerName = 'Agrita Abele'
ORDER BY 
              [OrderDetails!1!SalesOrderID]
            , [SalesPerson!2!SalesPersonName]  
            , [LineItem!3!LineTotal!ELEMENT]  
FOR XML EXPLICIT, ROOT('SalesOrders') ;   
