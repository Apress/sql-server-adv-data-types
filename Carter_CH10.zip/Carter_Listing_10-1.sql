SELECT *
FROM sys.spatial_reference_systems ;
