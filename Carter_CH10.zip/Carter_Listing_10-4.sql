DECLARE @CurvePolygon GEOGRAPHY = 
        'CURVEPOLYGON(CIRCULARSTRING(1 3, 3 5, 4 7, 7 3, 1 3))' ; 

SELECT @CurvePolygon ;
