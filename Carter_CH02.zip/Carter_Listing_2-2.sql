SELECT 
	  SalesOrder.OrderDate
	, SalesOrder.CustomerID
	, SalesOrder.OrderID
	, LineItem.StockItemID
	, LineItem.Quantity
	, LineItem.UnitPrice
FROM Sales.Orders SalesOrder
INNER JOIN Sales.OrderLines LineItem
	ON LineItem.OrderID = SalesOrder.OrderID
WHERE SalesOrder.OrderID IN 
(
3168,
4107,
4980,
64608,
73148
)
FOR XML AUTO, ROOT('SalesOrders') ;
