USE WideWorldImporters
GO


SELECT 
	  StockItemName
	, JSON_VALUE(CustomFields,'lax $.Tags[0]') AS Tag0
FROM Warehouse.StockItems
WHERE JSON_VALUE(CustomFields,'lax $.Tags[0]') = 'Radio Control'
	AND	ISJSON(CustomFields) = 1 ;
