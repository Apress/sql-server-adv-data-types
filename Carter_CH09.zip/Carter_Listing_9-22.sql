USE WideWorldImporters
GO

CREATE NONCLUSTERED INDEX NCI_CustomFieldsTag0
	ON Warehouse.NewStockItems(CustomFieldsTag0) ;
