USE WideWorldImporters
GO

SELECT 
	  StockItemName
	, JSON_VALUE(CustomFields,'lax $.Tags[0]') AS Tag0
	, JSON_VALUE(CustomFields,'lax $.Tags[1]') AS Tag1
	, JSON_VALUE(CustomFields,'lax $.Tags[2]') AS Tag2
	, JSON_QUERY(CustomFields,'lax $.Tags') AS TagsArray
FROM Warehouse.StockItems
WHERE StockItemID = 61 ;
