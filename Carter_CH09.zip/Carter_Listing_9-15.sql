USE WideWorldImporters
GO


UPDATE StockItems
	SET CustomFields = JSON_MODIFY(CustomFields,'append lax $.Tags', 'Vintage')
FROM Warehouse.StockItems
WHERE StockItemID = 61 ;
