USE WideWorldImporters
GO

--Copy data to a new table

SELECT *
INTO Warehouse.NewStockItems
FROM Warehouse.StockItems

--Clear plan chahe

DBCC FREEPROCCACHE

--Clear buffer cache

DBCC DROPCLEANBUFFERS

--Turn on statistics

SET STATISTICS TIME ON

SELECT 
	  StockItemName
	, JSON_VALUE(CustomFields,'lax $.Tags[0]') AS Tag0
	, JSON_VALUE(CustomFields,'lax $.Tags[1]') AS Tag1
	, JSON_VALUE(CustomFields,'lax $.Tags[2]') AS Tag2
	, JSON_QUERY(CustomFields,'lax $.Tags') AS TagsArray
FROM Warehouse.NewStockItems
WHERE JSON_VALUE(CustomFields,'lax $.Tags[0]') = 'Radio Control' ;
