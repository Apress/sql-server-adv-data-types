--Create a temp table

CREATE TABLE #JsonTemp
(
	JSONData	NVARCHAR(MAX)
) ;

--Populate temp table with one JSON value and one non-JSON value

INSERT INTO #JsonTemp
VALUES ('{"I am JSON":"True"}'),
       ('I am JSON - False') ;

--Call OPENJSON() against only rows where data is JSON

SELECT JSON.*
FROM #JsonTemp Base
OUTER APPLY OPENJSON(Base.JSONData) JSON 
WHERE ISJSON(Base.JSONData) = 1 ;

--Drop temp table

DROP TABLE #JsonTemp ;
