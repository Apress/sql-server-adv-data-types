USE WideWorldImporters
GO


SELECT 
	  StockItemName
	, JSON_VALUE(customfields,'lax $.Tags[0]')
FROM Warehouse.StockItems ;
