DECLARE @JSON NVARCHAR(MAX) ;

SET @JSON = '{"I am not:"Correctly formatted"}' ;


IF ISJSON(@JSON) = 1
BEGIN
	SELECT * 
	FROM OPENJSON(@JSON) ;
END
