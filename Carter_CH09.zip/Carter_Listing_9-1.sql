DECLARE @JSON NVARCHAR(MAX) ;

SET @JSON = '{"I am not:"Correctly formatted"}' ;

SELECT * 
FROM OPENJSON(@JSON) ;
