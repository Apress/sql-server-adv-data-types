USE WideWorldImporters
GO


UPDATE StockItems
	SET CustomFields = JSON_MODIFY(CustomFields,'lax $.Tags',NULL)
FROM Warehouse.StockItems
WHERE StockItemID = 61 ;
