USE WideWorldImporters
GO

ALTER TABLE Warehouse.NewStockItems
	ADD CustomFieldsTag0 AS JSON_VALUE(CustomFields,'lax $.Tags[0]') ;
