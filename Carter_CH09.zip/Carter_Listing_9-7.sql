USE WideWorldImporters
GO


SELECT 
	  StockItemName
	, JSON_VALUE(CustomFields,'lax $.Tags[0]') AS Tag0
	, JSON_VALUE(CustomFields,'lax $.Tags[1]') AS Tag1
	, JSON_VALUE(CustomFields,'lax $.Tags[2]') AS Tag2
FROM Warehouse.StockItems
WHERE JSON_VALUE(CustomFields,'strict $.Tags[0]') = 'Radio Control'
	AND JSON_VALUE(CustomFields,'strict $.Tags[2]') = 'Vintage'
	AND	ISJSON(CustomFields) = 1 ;
