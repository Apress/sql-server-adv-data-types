USE WideWorldImporters
GO

DECLARE @Path NVARCHAR(MAX) = '$' ;

SELECT 
	  StockItemName
	, JSON_VALUE(CustomFields,'lax $.Tags[0]') AS Tag0
	, JSON_VALUE(CustomFields,'lax $.Tags[1]') AS Tag1
	, JSON_VALUE(CustomFields,'lax $.Tags[2]') AS Tag2
	, JSON_QUERY(CustomFields,'lax $.Tags') AS TagsArray
	, JSON_QUERY(CustomFields, @Path) AS EntireDocument
FROM Warehouse.StockItems
WHERE JSON_QUERY(CustomFields,'strict $.Tags') <> '[]'
	AND	ISJSON(CustomFields) = 1 ;
