DECLARE @JSON NVARCHAR(MAX) ;


--The CustomFileds column for StockItem ID 61 contains the following JSON document:
--'{ "CountryOfManufacture": "China", "Tags": ["Radio Control","Realistic Sound"], "MinimumAge": "10" }'

SET @JSON = (SELECT CustomFields FROM Warehouse.StockItems WHERE StockItemID = 61) ;


IF ISJSON(@JSON) = 1
BEGIN
	SELECT JSON_VALUE(@Json,'lax $.Tags[0]') ;
END
