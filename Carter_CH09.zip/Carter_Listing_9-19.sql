USE WideWorldImporters
GO

SELECT 
	  StockItemName
	, JSON_QUERY(CustomFields,'lax $') AS EntireDocument
FROM Warehouse.StockItems
WHERE StockItemID = 61 ;
