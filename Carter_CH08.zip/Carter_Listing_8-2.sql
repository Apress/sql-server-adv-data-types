USE WideWorldImporters
GO

DECLARE @CustomFields NVARCHAR(MAX) ;

SET @CustomFields = (
	SELECT CustomFields
	FROM Application.People
	WHERE FullName = 'Anthony Grosse'
) ;

SELECT *
FROM OPENJSON(@CustomFields) ;
