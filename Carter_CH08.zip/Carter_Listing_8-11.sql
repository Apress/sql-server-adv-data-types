DECLARE @JSON NVARCHAR(MAX) ;

SET @JSON = '{
   "SalesOrders": [
      {
         "OrderID": 72646,
         "CustomerID": 1060,
         "SalespersonPersonID": 14,
         "OrderDate": "2016-05-18"
      },
      {
         "OrderID": 72738,
         "CustomerID": 1060,
         "SalespersonPersonID": 14,
         "OrderDate": "2016-05-19"
      },
      {
         "OrderID": 72916,
         "CustomerID": 1060,
         "SalespersonPersonID": 6,
         "OrderDate": "2016-05-20"
      },
      {
         "OrderID": 73081,
         "CustomerID": 1060,
         "SalespersonPersonID": 8,
         "OrderDate": "2016-05-24"
      }
   ]
}
' ;
