SELECT 
	  PersonID
	, FullName
	, JSON.*
FROM Application.People
OUTER APPLY OPENJSON(CustomFields) 
				WITH (
					  OtherLanguages NVARCHAR(MAX) AS JSON
					, HireDate DATETIME2
					, Title NVARCHAR(50)
					, PrimarySalesTerritory NVARCHAR(50)
					, CommissionRate DECIMAL(5,2)
				) JSON ;
