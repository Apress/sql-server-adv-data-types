USE WideWorldImporters
GO

SELECT 
	  PersonID
	, FullName
	, [OtherLanguages]
	, [HireDate]
	, [Title]
	, [PrimarySalesTerritory]
	, [CommissionRate]
FROM (
SELECT 
	  PersonID
	, FullName
	, JSON.[Key] AS JSONName
	, JSON.value AS JSONValue
FROM Application.People
OUTER APPLY OPENJSON(CustomFields) JSON
) Src
PIVOT
(
MAX(JSONValue)
FOR JSONName IN ([OtherLanguages], [HireDate], [Title], [PrimarySalesTerritory], [CommissionRate])
) pvt ;
