DECLARE @Columns NVARCHAR(MAX) ;
DECLARE @SQL NVARCHAR(MAX) ;

SET @Columns = '';

SELECT @Columns += ', p.' + QUOTENAME(JSONName)
FROM (
SELECT DISTINCT
	JSON.[Key] AS JSONName
FROM Application.People p
CROSS APPLY OPENJSON(CustomFields) JSON
) AS cols ;


SET @SQL = 
'SELECT 
	  PersonID
	, FullName
	, ' + STUFF(@Columns, 1, 2, '') + '
FROM
(
  SELECT 
	  PersonID
	, FullName
	, JSON.[Key] AS JSONName
	, JSON.value AS JSONValue
FROM Application.People
OUTER APPLY OPENJSON(CustomFields) JSON
) AS src
PIVOT
(
  MAX(JSONValue) FOR JSONName IN ('
  + STUFF(REPLACE(@Columns, ', p.[', ',['), 1, 1, '')
  + ')
) AS p ;' ;

EXEC (@SQL) ;
