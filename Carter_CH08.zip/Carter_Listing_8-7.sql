DECLARE @CustomFields NVARCHAR(MAX) ;

SET @CustomFields = 
(
SELECT
	CustomFields
FROM Application.People
WHERE PersonID = 2
) ;

SELECT *
FROM OPENJSON(@CustomFields)
WITH (
	  OtherLanguages NVARCHAR(MAX)
	, HireDate DATETIME2
	, Title NVARCHAR(50)
	, PrimarySalesTerritory NVARCHAR(50)
	, CommissionRate DECIMAL(5,2)
) ;
