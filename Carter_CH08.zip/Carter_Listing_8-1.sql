USE WideWorldImporters
GO

SELECT 
      PersonID
	, FullName
	, CustomFields
FROM Application.People ;
